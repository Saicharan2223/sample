export class User{
    constructor(public uid:number,public uname:string, public urole:string){}
}